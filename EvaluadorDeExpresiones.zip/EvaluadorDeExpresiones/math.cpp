//module math;
//
//#include "math.ixx"
//
//export float substractionOperation(float back1, float back2)
//{
//    return back2 - back1;
//}
//
//float multiplicationOperation(float back1, float back2)
//{
//    return back2 * back1;
//}
//
//float moduleOperation(float back1, float back2)
//{
//    return fmod(back1, back2);
//}
//
//float divisionOperation(float back1, float back2)
//{
//    return back2 / back1;
//}
//
//float powerOperation(float back1, float back2)
//{
//    return pow(back2, back1);
//}